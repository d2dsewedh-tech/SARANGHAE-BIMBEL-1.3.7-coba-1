package com.saranghae.bimbel;

import android.app.*;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    DB db;
    LinearLayout content;
    int purple,purpleDark,purpleSoft,pink,green,orange,blue,text,muted,bg,white;
    String currentScreen="home";

    String today(){ return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db=new DB(this);
        purple=getColor(R.color.purple); purpleDark=getColor(R.color.purple_dark); purpleSoft=getColor(R.color.purple_soft);
        pink=getColor(R.color.pink); green=getColor(R.color.green); orange=getColor(R.color.orange); blue=getColor(R.color.blue);
        text=getColor(R.color.text); muted=getColor(R.color.muted); bg=getColor(R.color.bg); white=getColor(R.color.white);
        getWindow().setStatusBarColor(purpleDark);
        getWindow().setNavigationBarColor(white);
        if(android.os.Build.VERSION.SDK_INT>=29){ getWindow().setStatusBarContrastEnforced(false); getWindow().setNavigationBarContrastEnforced(false); }
        getWindow().getDecorView().setSystemUiVisibility(0);
        showHome();
    }

    @Override public void onBackPressed(){
        if(!"home".equals(currentScreen)) showHome(); else super.onBackPressed();
    }

    TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    GradientDrawable rounded(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    GradientDrawable stroke(int fill,int line,float r){ GradientDrawable g=rounded(fill,r); g.setStroke(1,line); return g; }
    LinearLayout base(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(bg); return r; }

    Button btn(String s, View.OnClickListener l){
        Button b=new Button(this); b.setText(s); b.setTextColor(white); b.setTextSize(15); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setGravity(Gravity.CENTER); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(dp(12),0,dp(12),0); b.setBackground(rounded(purple,28)); b.setOnClickListener(l); return b;
    }

    void shell(String title,String subtitle,int selected){
        currentScreen = selected==0?"home":selected==1?"students":selected==2?"attendance":selected==3?"payment":"progress";
        LinearLayout root=base();
        root.setClipToPadding(false);

        LinearLayout toolbar=new LinearLayout(this); toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setPadding(dp(16),dp(8),dp(16),dp(8)); toolbar.setBackgroundColor(purple);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=tv(selected==0?"☰":"‹", selected==0?25:34, white); back.setGravity(Gravity.CENTER); back.setContentDescription(selected==0?"Menu":"Kembali");
        back.setOnClickListener(v->{ if(selected==0) Toast.makeText(this,"Menu utama",Toast.LENGTH_SHORT).show(); else showHome(); });
        top.addView(back,new LinearLayout.LayoutParams(dp(46),dp(50)));
        TextView titleView=tv(title, selected==0?20:20, white); titleView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        titleView.setSingleLine(true); titleView.setEllipsize(TextUtils.TruncateAt.END); titleView.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(titleView,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView action=tv(selected==0?"♢":"+", selected==0?25:28, white); action.setGravity(Gravity.CENTER); action.setContentDescription(selected==0?"Notifikasi":"Tambah");
        if(selected==0) action.setOnClickListener(v->Toast.makeText(this,"Belum ada notifikasi",Toast.LENGTH_SHORT).show());
        top.addView(action,new LinearLayout.LayoutParams(dp(46),dp(50))); toolbar.addView(top);
        if(selected==0){
            TextView sub=tv(subtitle,11,0xFFEDE8FF); sub.setSingleLine(true); sub.setEllipsize(TextUtils.TruncateAt.END);
            sub.setGravity(Gravity.CENTER); sub.setPadding(dp(46),0,dp(46),0);
            toolbar.addView(sub,new LinearLayout.LayoutParams(-1,dp(24)));
        }

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        // Extra bottom breathing room prevents the last card/button from feeling hidden
        // near the fixed bottom navigation on short screens.
        content.setPadding(dp(16),dp(14),dp(16),dp(40));
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));

        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(5),dp(5),dp(5),dp(5)); nav.setBackgroundColor(white); nav.setElevation(dp(6));
        String[] icons={"⌂","♙","✓","Rp","↗"}; String[] labels={"Beranda","Siswa","Absensi","Bayar","Progres"};
        View.OnClickListener[] click={v->showHome(),v->showStudents(),v->showAttendance(),v->showPayments(),v->showProgress()};
        for(int i=0;i<5;i++){
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); item.setClickable(true); item.setFocusable(true); item.setPadding(dp(2),dp(2),dp(2),dp(2));
            if(i==selected) item.setBackground(rounded(0x18C7B6FF,18));
            TextView ic=tv(icons[i],20,i==selected?purple:muted); ic.setGravity(Gravity.CENTER); ic.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            TextView la=tv(labels[i],11,i==selected?purple:muted); la.setGravity(Gravity.CENTER); la.setTypeface(Typeface.DEFAULT,i==selected?Typeface.BOLD:Typeface.NORMAL);
            item.addView(ic,new LinearLayout.LayoutParams(-1,dp(25))); item.addView(la,new LinearLayout.LayoutParams(-1,dp(20))); item.setOnClickListener(click[i]);
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(62),1));
        }
        // Let the toolbar measure itself from its real children. A fixed 68dp height
        // was too short because it contains both a title row and a subtitle row.
        root.addView(toolbar,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(72)));

        // Android can place content under system bars on some devices. Apply insets to the
        // whole app so toolbar stays below the status bar and bottom navigation stays above
        // the gesture/navigation area. This also works across Android 8 through Android 15+.
        root.setOnApplyWindowInsetsListener((v,insets)->{
            int insetTop=insets.getSystemWindowInsetTop();
            int insetBottom=insets.getSystemWindowInsetBottom();
            v.setPadding(0,insetTop,0,insetBottom);
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
    }

    TextView section(String s){ TextView t=tv(s,18,text); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(2,7,2,9); return t; }
    void gap(int h){ Space s=new Space(this); content.addView(s,new LinearLayout.LayoutParams(1,dp(h))); }
    void addBox(View v){ LinearLayout b=new LinearLayout(this); b.setPadding(dp(14),dp(12),dp(14),dp(12)); b.setOrientation(LinearLayout.VERTICAL); b.setBackground(stroke(white,0x15000000,20)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); b.addView(v); content.addView(b,p); }

    void showHome(){
        shell("SARANGHAE BIMBEL","Belajar seru • Tumbuh bersama • Prestasi Hebat",0);

        HeroView hero=new HeroView(this);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(178));
        hp.setMargins(-dp(16),0,-dp(16),0);
        content.addView(hero,hp);
        gap(8);

        LinearLayout welcome=new LinearLayout(this); welcome.setOrientation(LinearLayout.VERTICAL);
        welcome.setPadding(dp(16),dp(13),dp(16),dp(13)); welcome.setBackground(rounded(0xFFF0ECFF,22));
        TextView h=tv("Halo, Tutor! 👋",20,purpleDark); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); welcome.addView(h);
        welcome.addView(tv("Siap mendampingi anak-anak belajar hari ini?",13,muted));
        TextView ver=tv("Versi 1.3.6 • UI Responsif • Lebih Lega",11,purple); ver.setTypeface(Typeface.DEFAULT,Typeface.BOLD); ver.setPadding(0,dp(7),0,0); welcome.addView(ver);
        content.addView(welcome); gap(10);

        int siswa=db.count("siswa"), hadir=db.countWhere("absensi","tanggal='"+today()+"' AND status='Hadir'"), belum=db.countWhere("pembayaran","status!='Lunas'"), prog=db.count("progres");
        content.addView(section("Ringkasan Hari Ini"));
        LinearLayout r1=new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL); stat(r1,"●",siswa,"Total Siswa",purple); stat(r1,"✓",hadir,"Hadir Hari Ini",green); content.addView(r1);
        LinearLayout r2=new LinearLayout(this); r2.setOrientation(LinearLayout.HORIZONTAL); stat(r2,"Rp",belum,"Belum Bayar",blue); stat(r2,"↗",prog,"Catatan Progres",orange); content.addView(r2);
        content.addView(section("Menu Utama"));
        menu("♟","Data Siswa","Kelola data dan program belajar",purple,v->showStudents());
        menu("✓","Absensi","Catat kehadiran siswa hari ini",green,v->showAttendance());
        menu("Rp","Pembayaran","Catat dan cek status pembayaran",blue,v->showPayments());
        menu("↗","Progres Anak","Pantau nilai dan perkembangan belajar",orange,v->showProgress());
    }

    static class HeroView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Path path=new Path(); RectF r=new RectF();
        HeroView(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void fill(Canvas c,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);}
        void circle(Canvas c,float x,float y,float rad,int color){fill(c,color);c.drawCircle(x,y,rad,p);}
        void round(Canvas c,float l,float t,float rr,float b,float rad,int color){fill(c,color);r.set(l,t,rr,b);c.drawRoundRect(r,rad,rad,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight();
            fill(c,0xFFF9F4FF);c.drawRect(0,0,w,h,p);
            path.reset(); path.moveTo(0,h*.35f); path.quadTo(w*.25f,h*.08f,w*.52f,h*.28f); path.quadTo(w*.78f,h*.52f,w,h*.20f); path.lineTo(w,h);path.lineTo(0,h);path.close();fill(c,0xFFF0CBEA);c.drawPath(path,p);
            // stars/hearts
            p.setTextSize(dpStatic(22));p.setColor(0xFFD9B6FF);c.drawText("♡",w*.08f,h*.28f,p);c.drawText("♡",w*.78f,h*.22f,p);p.setTextSize(dpStatic(18));p.setColor(0xFFFFD95A);c.drawText("★",w*.70f,h*.30f,p);
            // boy backpack/body
            round(c,w*.18f,h*.55f,w*.39f,h*.93f,18,0xFF4B91E2);round(c,w*.15f,h*.57f,w*.23f,h*.88f,12,0xFF285EAA);
            circle(c,w*.285f,h*.44f,h*.13f,0xFFFFD4B8);round(c,w*.20f,h*.31f,w*.37f,h*.44f,55,0xFF303446);circle(c,w*.25f,h*.45f,h*.018f,0xFF242335);circle(c,w*.32f,h*.45f,h*.018f,0xFF242335);
            // girl
            round(c,w*.55f,h*.56f,w*.78f,h*.94f,20,0xFFF06A9A);round(c,w*.53f,h*.59f,w*.60f,h*.90f,12,0xFF8E4FBD);
            circle(c,w*.665f,h*.44f,h*.135f,0xFFFFD4B8);circle(c,w*.57f,h*.42f,h*.09f,0xFF633E34);circle(c,w*.75f,h*.42f,h*.09f,0xFF633E34);
            circle(c,w*.625f,h*.45f,h*.018f,0xFF242335);circle(c,w*.70f,h*.45f,h*.018f,0xFF242335);
            // books
            round(c,w*.40f,h*.78f,w*.61f,h*.86f,5,0xFF6C4DE6);round(c,w*.43f,h*.71f,w*.65f,h*.79f,5,0xFFFFC857);
            p.setTextSize(dpStatic(14));p.setColor(0xFF6C4DE6);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Semangat",w*.72f,h*.55f,p);c.drawText("Belajar!",w*.75f,h*.66f,p);
        }
        float dpStatic(float v){return v*getResources().getDisplayMetrics().density;}
    }

    void stat(LinearLayout parent,String icon,int number,String name,int color){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(dp(7),dp(9),dp(7),dp(8)); box.setBackground(stroke(white,0x15000000,18));
        TextView i=tv(icon,18,color); i.setGravity(Gravity.CENTER); box.addView(i,new LinearLayout.LayoutParams(-1,dp(25)));
        TextView n=tv(""+number,22,text); n.setGravity(Gravity.CENTER); n.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(n,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView l=tv(name,10,muted); l.setGravity(Gravity.CENTER); l.setMaxLines(2); l.setIncludeFontPadding(true); box.addView(l,new LinearLayout.LayoutParams(-1,dp(19)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(118),1); p.setMargins(dp(3),0,dp(3),dp(9)); parent.addView(box,p);
    }

    void menu(String icon,String title,String sub,int color,View.OnClickListener listener){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER_VERTICAL); box.setPadding(dp(10),dp(7),dp(10),dp(7)); box.setBackground(stroke(white,0x15000000,18)); box.setClickable(true); box.setOnClickListener(listener);
        TextView ic=tv(icon,20,color); ic.setGravity(Gravity.CENTER); ic.setBackground(rounded(0x18FFFFFF|color,16)); box.addView(ic,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(12),0,dp(7),0);
        TextView t=tv(title,15,text); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); tx.addView(t,new LinearLayout.LayoutParams(-1,dp(23)));
        TextView s=tv(sub,11,muted); s.setSingleLine(true); s.setEllipsize(TextUtils.TruncateAt.END); tx.addView(s,new LinearLayout.LayoutParams(-1,dp(19)));
        box.addView(tx,new LinearLayout.LayoutParams(0,dp(48),1)); TextView ar=tv("›",27,muted); ar.setGravity(Gravity.CENTER); box.addView(ar,new LinearLayout.LayoutParams(dp(28),dp(48)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(78)); p.setMargins(0,0,0,dp(9)); content.addView(box,p);
    }

    void showStudents(){
        shell("Data Siswa","Kelola data siswa dengan cepat dan rapi",1);
        Button add=btn("＋  Tambah Siswa",v->formStudent(0,"","","")); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(50)); ap.setMargins(0,0,0,dp(10)); content.addView(add,ap);
        Cursor c=db.get("SELECT id,nama,kelas,program FROM siswa ORDER BY nama");
        if(!c.moveToFirst()){ content.addView(empty("Belum ada siswa","Tambahkan siswa pertama untuk memulai.")); c.close(); return; }
        do{ final int id=c.getInt(0); final String n=c.getString(1),cl=c.getString(2),pr=c.getString(3);
            LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER_VERTICAL); box.setPadding(dp(11),dp(9),dp(8),dp(9)); box.setBackground(stroke(white,0x15000000,18));
            TextView av=tv(initials(n),15,white); av.setGravity(Gravity.CENTER); av.setTypeface(Typeface.DEFAULT,Typeface.BOLD); av.setBackground(rounded(purple,50)); box.addView(av,new LinearLayout.LayoutParams(dp(46),dp(46)));
            LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(12,0,5,0); TextView nm=tv(n,15,text); nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD); tx.addView(nm,new LinearLayout.LayoutParams(-1,dp(24)));
            TextView detail=tv((cl.isEmpty()?"Kelas belum diisi":cl)+" • "+(pr.isEmpty()?"Program belum diisi":pr),11,muted); detail.setSingleLine(true); detail.setEllipsize(TextUtils.TruncateAt.END); tx.addView(detail,new LinearLayout.LayoutParams(-1,dp(19))); box.addView(tx,new LinearLayout.LayoutParams(0,dp(46),1));
            TextView more=tv("⋮",23,muted); more.setGravity(Gravity.CENTER); box.addView(more,new LinearLayout.LayoutParams(dp(30),dp(46))); box.setOnClickListener(v->studentActions(id,n,cl,pr));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(74)); p.setMargins(0,0,0,dp(8)); content.addView(box,p);
        }while(c.moveToNext()); c.close();
    }
    String initials(String n){ String[] a=n.trim().split("\\s+"); if(a.length==0||a[0].isEmpty()) return "?"; return a.length==1?a[0].substring(0,1).toUpperCase():(a[0].substring(0,1)+a[a.length-1].substring(0,1)).toUpperCase(); }
    TextView empty(String title,String sub){ TextView t=tv("📚\n"+title+"\n"+sub,14,muted); t.setGravity(Gravity.CENTER); t.setPadding(18,25,18,25); t.setBackground(stroke(white,0x15000000,20)); return t; }
    void studentActions(final int id,final String n,final String cl,final String p){ new AlertDialog.Builder(this).setTitle(n).setItems(new String[]{"✏  Edit siswa","🗑  Hapus siswa"},(d,w)->{ if(w==0)formStudent(id,n,cl,p); else new AlertDialog.Builder(this).setTitle("Hapus siswa?").setMessage("Data absensi, pembayaran, dan progres siswa ini juga akan dihapus.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(x,y)->{db.deleteStudent(id);showStudents();}).show(); }).show(); }
    void formStudent(int id,String oldN,String oldC,String oldP){ shell(id==0?"Tambah Siswa":"Edit Siswa","Lengkapi informasi siswa",1); content.addView(section("Informasi Siswa")); EditText n=input("Nama siswa *",oldN),cl=input("Kelas sekolah",oldC),p=input("Program / mata pelajaran",oldP); content.addView(n);content.addView(cl);content.addView(p); Button save=btn("Simpan Data",v->{String nn=n.getText().toString().trim();if(nn.isEmpty()){n.setError("Nama wajib diisi");return;}db.saveStudent(id,nn,cl.getText().toString().trim(),p.getText().toString().trim());Toast.makeText(this,"Data siswa tersimpan ✓",Toast.LENGTH_SHORT).show();showStudents();}); content.addView(save,new LinearLayout.LayoutParams(-1,dp(52))); }
    EditText input(String hint,String value){ EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextSize(14);e.setTextColor(text);e.setHintTextColor(muted);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(stroke(white,0x18000000,16));e.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(52)));((LinearLayout.LayoutParams)e.getLayoutParams()).setMargins(0,0,0,9);return e; }

    void showAttendance(){
        shell("Absensi","Kelola 8 pertemuan setiap murid",2);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button report=btn("▤  Laporan",v->showAttendanceReport());
        actions.addView(report,new LinearLayout.LayoutParams(0,dp(48),1));
        content.addView(actions); gap(10);

        Cursor c=db.get("SELECT id,nama,kelas FROM siswa ORDER BY nama");
        if(!c.moveToFirst()){content.addView(empty("Belum ada siswa","Tambahkan siswa terlebih dahulu."));c.close();return;}
        do{
            final int id=c.getInt(0); final String name=c.getString(1); final String kelas=c.getString(2);
            int hadir=db.countAttendance(id,"Hadir"), izin=db.countAttendance(id,"Izin"), sakit=db.countAttendance(id,"Sakit"), alpa=db.countAttendance(id,"Alpa");
            int terisi=hadir+izin+sakit+alpa;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(13),dp(11),dp(13),dp(11)); card.setBackground(stroke(white,0x15000000,18)); card.setClickable(true); card.setOnClickListener(v->showAttendanceDetail(id,name));
            LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
            TextView av=tv(initials(name),14,white); av.setGravity(Gravity.CENTER); av.setTypeface(Typeface.DEFAULT,Typeface.BOLD); av.setBackground(rounded(purple,50)); top.addView(av,new LinearLayout.LayoutParams(dp(44),dp(44)));
            LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(11),0,dp(5),0);
            TextView nm=tv(name,15,text); nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD); tx.addView(nm,new LinearLayout.LayoutParams(-1,dp(23)));
            tx.addView(tv((kelas.isEmpty()?"Kelas belum diisi":kelas)+" • "+terisi+" / 8 pertemuan",11,muted),new LinearLayout.LayoutParams(-1,dp(20)));
            top.addView(tx,new LinearLayout.LayoutParams(0,dp(44),1)); TextView ar=tv("›",27,muted); ar.setGravity(Gravity.CENTER); top.addView(ar,new LinearLayout.LayoutParams(dp(28),dp(44))); card.addView(top);
            LinearLayout stats=new LinearLayout(this); stats.setPadding(0,dp(8),0,0);
            miniStat(stats,"Hadir",hadir,green); miniStat(stats,"Izin",izin,orange); miniStat(stats,"Sakit",sakit,blue); miniStat(stats,"Alpa",alpa,pink); card.addView(stats);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,0,0,dp(9)); content.addView(card,cp);
        }while(c.moveToNext()); c.close();
        TextView hint=tv("Tip: ketuk nama murid untuk mengisi Pertemuan 1–8 beserta tanggal dan statusnya.",11,muted); hint.setPadding(dp(4),dp(4),dp(4),dp(12)); content.addView(hint);
    }

    void miniStat(LinearLayout parent,String label,int n,int color){
        LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); x.setGravity(Gravity.CENTER); x.setPadding(dp(2),dp(4),dp(2),dp(3));
        TextView num=tv(""+n,14,color); num.setGravity(Gravity.CENTER); num.setTypeface(Typeface.DEFAULT,Typeface.BOLD); x.addView(num,new LinearLayout.LayoutParams(-1,dp(20)));
        TextView lab=tv(label,9,muted); lab.setGravity(Gravity.CENTER); x.addView(lab,new LinearLayout.LayoutParams(-1,dp(17)));
        parent.addView(x,new LinearLayout.LayoutParams(0,dp(43),1));
    }

    void showAttendanceDetail(final int sid, final String name){
        shell("Absensi "+name,"8 pertemuan • tanggal • status",2);
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(dp(14),dp(11),dp(14),dp(11)); head.setBackground(rounded(0xFFF0ECFF,18));
        int h=db.countAttendance(sid,"Hadir"),i=db.countAttendance(sid,"Izin"),s=db.countAttendance(sid,"Sakit"),a=db.countAttendance(sid,"Alpa");
        TextView title=tv("Rekap: "+h+" Hadir • "+i+" Izin • "+s+" Sakit • "+a+" Alpa",13,purpleDark); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.addView(title);
        head.addView(tv("Maksimal 8 pertemuan. Status dapat diubah kapan saja.",11,muted)); content.addView(head); gap(10);

        final ArrayList<String> dates=new ArrayList<>(); final ArrayList<String> states=new ArrayList<>();
        for(int slot=1;slot<=8;slot++){
            String d=db.attendanceDate(sid,slot), st=db.attendanceStatusBySlot(sid,slot);
            dates.add(d==null?"":d); states.add(st==null?"Belum":st);
            attendanceSlot(sid,name,slot,dates,states);
        }
        Button save=btn("▣  Simpan 8 Pertemuan",v->{
            for(int k=0;k<8;k++){
                String st=states.get(k), d=dates.get(k);
                if("Belum".equals(st)){ db.deleteAttendanceSlot(sid,k+1); continue; }
                if(d==null||d.isEmpty()){ d=today(); dates.set(k,d); }
                db.saveAttendanceSlot(sid,k+1,d,st);
            }
            Toast.makeText(this,"Absensi "+name+" tersimpan ✓",Toast.LENGTH_SHORT).show(); showAttendanceDetail(sid,name);
        });
        content.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));
        gap(8); content.addView(btn("←  Kembali ke Daftar Absensi",v->showAttendance()),new LinearLayout.LayoutParams(-1,dp(48)));
    }

    void attendanceSlot(final int sid, String name, final int slot, final ArrayList<String> dates, final ArrayList<String> states){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12),dp(9),dp(12),dp(10)); card.setBackground(stroke(white,0x15000000,16));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView no=tv("Pertemuan "+slot,14,text); no.setTypeface(Typeface.DEFAULT,Typeface.BOLD); top.addView(no,new LinearLayout.LayoutParams(0,dp(25),1));
        TextView status=tv(states.get(slot-1),10,statusColor(states.get(slot-1))); status.setGravity(Gravity.CENTER); status.setTypeface(Typeface.DEFAULT,Typeface.BOLD); status.setBackground(rounded(0x12000000|statusColor(states.get(slot-1)),20)); top.addView(status,new LinearLayout.LayoutParams(dp(70),dp(25))); card.addView(top);

        final TextView dateBtn=tv(dates.get(slot-1).isEmpty()?"📅  Pilih tanggal":formatDateShort(dates.get(slot-1)),dates.get(slot-1).isEmpty()?muted:text); dateBtn.setGravity(Gravity.CENTER); dateBtn.setTypeface(Typeface.DEFAULT,Typeface.BOLD); dateBtn.setBackground(stroke(white,0x22000000,12));
        dateBtn.setOnClickListener(v->{
            Calendar cal=Calendar.getInstance(); String old=dates.get(slot-1); if(!old.isEmpty())try{cal.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(old));}catch(Exception ignored){}
            DatePickerDialog dlg=new DatePickerDialog(this,(view,y,m,d)->{String val=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);dates.set(slot-1,val);dateBtn.setText("📅  "+formatDateShort(val));dateBtn.setTextColor(text);},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)); dlg.show();
        });
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,dp(40)); dp.setMargins(0,dp(7),0,dp(7)); card.addView(dateBtn,dp);

        LinearLayout choices=new LinearLayout(this); choices.setGravity(Gravity.CENTER); String[] opts={"Hadir","Izin","Sakit","Alpa"}; int[] cols={green,orange,blue,pink};
        for(int j=0;j<4;j++){
            final int ix=j; TextView b=tv(opts[j],10,states.get(slot-1).equals(opts[j])?white:cols[j]); b.setGravity(Gravity.CENTER); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(rounded(states.get(slot-1).equals(opts[j])?cols[j]:0x00FFFFFF,11));
            b.setOnClickListener(v->{states.set(slot-1,opts[ix]);status.setText(opts[ix]);status.setTextColor(white);status.setBackground(rounded(cols[ix],20)); if(dates.get(slot-1).isEmpty()){dates.set(slot-1,today());dateBtn.setText("📅  "+formatDateShort(today()));dateBtn.setTextColor(text);} for(int k=0;k<choices.getChildCount();k++){TextView q=(TextView)choices.getChildAt(k);boolean on=k==ix;q.setTextColor(on?white:cols[k]);q.setBackground(rounded(on?cols[k]:0x00FFFFFF,11));}});
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(34),1);bp.setMargins(dp(2),0,dp(2),0);choices.addView(b,bp);
        }
        card.addView(choices); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(130));cp.setMargins(0,0,0,dp(8));content.addView(card,cp);
    }

    int statusColor(String st){ if("Hadir".equals(st))return green; if("Izin".equals(st))return orange; if("Sakit".equals(st))return blue; if("Alpa".equals(st))return pink; return muted; }
    String formatDateShort(String iso){ try{return new SimpleDateFormat("dd MMM yyyy",new Locale("id","ID")).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso));}catch(Exception e){return iso;} }

    void showAttendanceReport(){
        shell("Laporan Absensi","Rekap kehadiran seluruh murid",2);
        content.addView(section("Ringkasan 8 Pertemuan"));
        Cursor c=db.get("SELECT id,nama,kelas FROM siswa ORDER BY nama");
        if(!c.moveToFirst()){content.addView(empty("Belum ada siswa","Tambahkan siswa terlebih dahulu."));c.close();return;}
        do{
            int sid=c.getInt(0); String name=c.getString(1), kelas=c.getString(2);
            int h=db.countAttendance(sid,"Hadir"),i=db.countAttendance(sid,"Izin"),s=db.countAttendance(sid,"Sakit"),a=db.countAttendance(sid,"Alpa"), total=h+i+s+a;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(13),dp(11),dp(13),dp(11));card.setBackground(stroke(white,0x15000000,18));
            TextView nm=tv(name,15,text);nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(nm,new LinearLayout.LayoutParams(-1,dp(23)));
            card.addView(tv((kelas.isEmpty()?"":kelas+" • ")+"Terisi "+total+"/8 pertemuan",11,muted),new LinearLayout.LayoutParams(-1,dp(19)));
            LinearLayout row=new LinearLayout(this); row.setPadding(0,dp(7),0,0); reportPill(row,"Hadir",h,green); reportPill(row,"Izin",i,orange); reportPill(row,"Sakit",s,blue); reportPill(row,"Alpa",a,pink); card.addView(row);
            String last=db.lastAttendanceDate(sid); String ket=total==0?"Belum ada absensi":(total<8?"Masih ada "+(8-total)+" pertemuan":"8 pertemuan selesai");
            card.addView(tv("Terakhir: "+(last==null?"-":formatDateShort(last))+"  •  "+ket,11,text));
            StringBuilder riwayat=new StringBuilder("Riwayat: ");
            for(int slot=1;slot<=8;slot++){String rd=db.attendanceDate(sid,slot),rs=db.attendanceStatusBySlot(sid,slot);if(slot>1)riwayat.append("  |  ");riwayat.append(slot).append(". ").append(rd==null?"-":formatDateShort(rd)).append(" ").append(rs==null?"Belum":rs);}
            TextView hist=tv(riwayat.toString(),10,muted);hist.setMaxLines(4);hist.setPadding(0,dp(5),0,0);card.addView(hist);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(8));content.addView(card,cp);
        }while(c.moveToNext()); c.close();
        gap(4); content.addView(btn("←  Kembali ke Absensi",v->showAttendance()),new LinearLayout.LayoutParams(-1,dp(48)));
    }

    void reportPill(LinearLayout parent,String label,int n,int color){ TextView t=tv(label+" "+n,10,color);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setBackground(rounded(0x18FFFFFF|color,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(30),1);p.setMargins(dp(2),0,dp(2),0);parent.addView(t,p); }

    void showPayments(){
        shell("Pembayaran","Catat transaksi dan pantau tunggakan",3); content.addView(btn("＋  Catat Pembayaran",v->paymentForm()),new LinearLayout.LayoutParams(-1,dp(50)));gap(10);
        Cursor c=db.get("SELECT p.id,s.nama,p.periode,p.nominal,p.status FROM pembayaran p JOIN siswa s ON s.id=p.siswa_id ORDER BY p.id DESC");
        if(!c.moveToFirst()){content.addView(empty("Belum ada pembayaran","Transaksi yang Anda simpan akan muncul di sini."));c.close();return;}
        do{final int id=c.getInt(0);String name=c.getString(1),per=c.getString(2),st=c.getString(4);long nom=c.getLong(3);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(13),dp(10),dp(11),dp(10));box.setBackground(stroke(white,0x15000000,18));LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView nm=tv(name,15,text);nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(nm,new LinearLayout.LayoutParams(0,dp(24),1));TextView badge=tv(st.equals("Lunas")?"LUNAS":"BELUM",10,st.equals("Lunas")?green:pink);badge.setGravity(Gravity.CENTER);badge.setTypeface(Typeface.DEFAULT,Typeface.BOLD);badge.setBackground(rounded(st.equals("Lunas")?0x2238B873:0x22F36B9A,30));top.addView(badge,new LinearLayout.LayoutParams(dp(68),dp(26)));box.addView(top);box.addView(tv("📅 "+per+"   •   "+money(nom),12,muted));box.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Hapus pembayaran?").setMessage(name+" • "+per).setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{db.deletePayment(id);showPayments();}).show());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(74));p.setMargins(0,0,0,dp(8));content.addView(box,p);}while(c.moveToNext());c.close();
    }
    void paymentForm(){ shell("Catat Pembayaran","Simpan transaksi pembayaran siswa",3); Cursor c=db.get("SELECT id,nama FROM siswa ORDER BY nama");ArrayList<String> names=new ArrayList<>();final ArrayList<Integer> ids=new ArrayList<>();while(c.moveToNext()){ids.add(c.getInt(0));names.add(c.getString(1));}c.close();if(ids.isEmpty()){content.addView(empty("Belum ada siswa","Tambahkan siswa terlebih dahulu."));return;}Spinner siswa=new Spinner(this);siswa.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));EditText per=input("Periode, contoh: September 2026","");EditText nom=input("Nominal","");nom.setInputType(InputType.TYPE_CLASS_NUMBER);Spinner st=new Spinner(this);st.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Lunas","Belum Bayar"}));content.addView(section("Detail Transaksi"));content.addView(siswa);content.addView(per);content.addView(nom);content.addView(st);gap(8);content.addView(btn("Simpan Pembayaran",v->{String periode=per.getText().toString().trim();if(periode.isEmpty()){per.setError("Periode wajib diisi");return;}long nominal;try{nominal=Long.parseLong(nom.getText().toString().trim());}catch(Exception e){nom.setError("Nominal tidak valid");return;}if(nominal<0){nom.setError("Nominal tidak boleh negatif");return;}db.addPayment(ids.get(siswa.getSelectedItemPosition()),periode,nominal,st.getSelectedItem().toString());Toast.makeText(this,"Pembayaran tersimpan ✓",Toast.LENGTH_SHORT).show();showPayments();})); }
    String money(long n){return NumberFormat.getCurrencyInstance(new Locale("id","ID")).format(n).replace(",00","");}

    void showProgress(){
        shell("Progres Anak","Pantau nilai dan perkembangan belajar",4);content.addView(btn("＋  Tambah Progres",v->progressForm()),new LinearLayout.LayoutParams(-1,dp(50)));gap(10);Cursor c=db.get("SELECT pr.id,s.nama,pr.tanggal,pr.materi,pr.nilai,pr.catatan FROM progres pr JOIN siswa s ON s.id=pr.siswa_id ORDER BY pr.id DESC");
        if(!c.moveToFirst()){content.addView(empty("Belum ada catatan progres","Catatan perkembangan siswa akan muncul di sini."));c.close();return;}
        do{final int id=c.getInt(0);String name=c.getString(1),date=c.getString(2),materi=c.getString(3),cat=c.getString(5);int nilai=c.getInt(4);String stat=nilai>=80?"Baik":nilai>=60?"Cukup":"Perlu latihan";LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(13),dp(10),dp(11),dp(10));box.setBackground(stroke(white,0x15000000,18));LinearLayout top=new LinearLayout(this);TextView nm=tv(name,15,text);nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(nm,new LinearLayout.LayoutParams(0,dp(24),1));TextView score=tv("★ "+nilai,12,white);score.setGravity(Gravity.CENTER);score.setTypeface(Typeface.DEFAULT,Typeface.BOLD);score.setBackground(rounded(nilai>=80?green:nilai>=60?orange:pink,30));top.addView(score,new LinearLayout.LayoutParams(dp(60),dp(26)));box.addView(top);box.addView(tv("📚 "+materi+"  •  "+date,12,muted));box.addView(tv("Status: "+stat+(cat.isEmpty()?"":"\n"+cat),12,text));box.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Hapus catatan progres?").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{db.deleteProgress(id);showProgress();}).show());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));content.addView(box,p);}while(c.moveToNext());c.close();
    }
    void progressForm(){shell("Tambah Progres","Catat hasil belajar hari ini",4);Cursor c=db.get("SELECT id,nama FROM siswa ORDER BY nama");ArrayList<String> names=new ArrayList<>();final ArrayList<Integer> ids=new ArrayList<>();while(c.moveToNext()){ids.add(c.getInt(0));names.add(c.getString(1));}c.close();if(ids.isEmpty()){content.addView(empty("Belum ada siswa","Tambahkan siswa terlebih dahulu."));return;}Spinner siswa=new Spinner(this);siswa.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));EditText mat=input("Materi yang dipelajari *","");EditText nilai=input("Nilai 0-100 *","");nilai.setInputType(InputType.TYPE_CLASS_NUMBER);EditText cat=input("Catatan tutor","");cat.setSingleLine(false);cat.setMinHeight(80);content.addView(section("Hasil Belajar"));content.addView(siswa);content.addView(mat);content.addView(nilai);content.addView(cat);content.addView(btn("Simpan Progres",v->{String m=mat.getText().toString().trim();if(m.isEmpty()){mat.setError("Materi wajib diisi");return;}int nv;try{nv=Integer.parseInt(nilai.getText().toString().trim());}catch(Exception e){nilai.setError("Nilai harus 0-100");return;}if(nv<0||nv>100){nilai.setError("Nilai harus 0-100");return;}db.addProgress(ids.get(siswa.getSelectedItemPosition()),m,nv,cat.getText().toString().trim());Toast.makeText(this,"Progres tersimpan ✓",Toast.LENGTH_SHORT).show();showProgress();}));}

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"saranghae.db",null,4);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE siswa(id INTEGER PRIMARY KEY AUTOINCREMENT,nama TEXT NOT NULL,kelas TEXT,program TEXT)");d.execSQL("CREATE TABLE absensi(id INTEGER PRIMARY KEY AUTOINCREMENT,siswa_id INTEGER NOT NULL,tanggal TEXT NOT NULL,status TEXT NOT NULL,catatan TEXT,pertemuan INTEGER NOT NULL DEFAULT 0, UNIQUE(siswa_id,tanggal))");d.execSQL("CREATE TABLE pembayaran(id INTEGER PRIMARY KEY AUTOINCREMENT,siswa_id INTEGER NOT NULL,periode TEXT,nominal INTEGER,status TEXT)");d.execSQL("CREATE TABLE progres(id INTEGER PRIMARY KEY AUTOINCREMENT,siswa_id INTEGER NOT NULL,tanggal TEXT,materi TEXT,nilai INTEGER,catatan TEXT)");seed(d);}
        void seed(SQLiteDatabase d){d.execSQL("INSERT INTO siswa(nama,kelas,program) VALUES('Aisyah Putri','Kelas 5 SD','Matematika')");d.execSQL("INSERT INTO siswa(nama,kelas,program) VALUES('Bintang Ramadhan','Kelas 4 SD','Bahasa Indonesia')");d.execSQL("INSERT INTO siswa(nama,kelas,program) VALUES('Cinta Aulia','Kelas 6 SD','IPA')");d.execSQL("INSERT INTO siswa(nama,kelas,program) VALUES('Daffa Alif','Kelas 3 SD','Matematika')");}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
            if(oldV<2){d.execSQL("CREATE TABLE absensi_new(id INTEGER PRIMARY KEY AUTOINCREMENT,siswa_id INTEGER NOT NULL,tanggal TEXT NOT NULL,status TEXT NOT NULL,catatan TEXT, UNIQUE(siswa_id,tanggal))");d.execSQL("INSERT OR IGNORE INTO absensi_new(id,siswa_id,tanggal,status,catatan) SELECT id,siswa_id,tanggal,status,catatan FROM absensi");d.execSQL("DROP TABLE absensi");d.execSQL("ALTER TABLE absensi_new RENAME TO absensi");}
            if(oldV<3){Cursor c=d.rawQuery("SELECT COUNT(*) FROM siswa",null);c.moveToFirst();int n=c.getInt(0);c.close();if(n==0)seed(d);}
            if(oldV<4){d.execSQL("ALTER TABLE absensi ADD COLUMN pertemuan INTEGER NOT NULL DEFAULT 0");
                Cursor c=d.rawQuery("SELECT siswa_id,id FROM absensi ORDER BY siswa_id,tanggal,id",null);int lastSid=-1,slot=0;SQLiteDatabase w=d;
                while(c.moveToNext()){int sid=c.getInt(0),id=c.getInt(1);if(sid!=lastSid){lastSid=sid;slot=0;}slot++;w.execSQL("UPDATE absensi SET pertemuan=? WHERE id=?",new Object[]{slot,id});}c.close();}
        }
        Cursor get(String q){return getReadableDatabase().rawQuery(q,null);} int count(String t){Cursor c=get("SELECT COUNT(*) FROM "+t);c.moveToFirst();int n=c.getInt(0);c.close();return n;} int countWhere(String t,String w){Cursor c=get("SELECT COUNT(*) FROM "+t+" WHERE "+w);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        void saveStudent(int id,String n,String cl,String p){SQLiteDatabase d=getWritableDatabase();if(id==0)d.execSQL("INSERT INTO siswa(nama,kelas,program) VALUES(?,?,?)",new Object[]{n,cl,p});else d.execSQL("UPDATE siswa SET nama=?,kelas=?,program=? WHERE id=?",new Object[]{n,cl,p,id});}
        void deleteStudent(int id){SQLiteDatabase d=getWritableDatabase();d.execSQL("DELETE FROM absensi WHERE siswa_id=?",new Object[]{id});d.execSQL("DELETE FROM pembayaran WHERE siswa_id=?",new Object[]{id});d.execSQL("DELETE FROM progres WHERE siswa_id=?",new Object[]{id});d.execSQL("DELETE FROM siswa WHERE id=?",new Object[]{id});}
        String attendanceStatus(int sid,String date){Cursor c=get("SELECT status FROM absensi WHERE siswa_id="+sid+" AND tanggal='"+date+"' LIMIT 1");String s=null;if(c.moveToFirst())s=c.getString(0);c.close();return s;}
        int countAttendance(int sid,String status){Cursor c=get("SELECT COUNT(*) FROM absensi WHERE siswa_id="+sid+" AND status='"+status+"'");c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        String attendanceDate(int sid,int slot){Cursor c=get("SELECT tanggal FROM absensi WHERE siswa_id="+sid+" AND pertemuan="+slot+" ORDER BY id DESC LIMIT 1");String s=null;if(c.moveToFirst())s=c.getString(0);c.close();return s;}
        String attendanceStatusBySlot(int sid,int slot){Cursor c=get("SELECT status FROM absensi WHERE siswa_id="+sid+" AND pertemuan="+slot+" ORDER BY id DESC LIMIT 1");String s=null;if(c.moveToFirst())s=c.getString(0);c.close();return s;}
        String lastAttendanceDate(int sid){Cursor c=get("SELECT MAX(tanggal) FROM absensi WHERE siswa_id="+sid);String s=null;if(c.moveToFirst())s=c.getString(0);c.close();return s;}
        void saveAttendanceSlot(int sid,int slot,String date,String status){SQLiteDatabase d=getWritableDatabase();d.execSQL("DELETE FROM absensi WHERE siswa_id=? AND pertemuan=?",new Object[]{sid,slot});d.execSQL("DELETE FROM absensi WHERE siswa_id=? AND tanggal=?",new Object[]{sid,date});d.execSQL("INSERT INTO absensi(siswa_id,tanggal,status,catatan,pertemuan) VALUES(?,?,?,?,?)",new Object[]{sid,date,status,"",slot});}
        void deleteAttendanceSlot(int sid,int slot){getWritableDatabase().execSQL("DELETE FROM absensi WHERE siswa_id=? AND pertemuan=?",new Object[]{sid,slot});}
        void upsertAttendance(int sid,String date,String status){getWritableDatabase().execSQL("INSERT OR REPLACE INTO absensi(siswa_id,tanggal,status,catatan,pertemuan) VALUES(?,?,?,COALESCE((SELECT catatan FROM absensi WHERE siswa_id=? AND tanggal=?),''),COALESCE((SELECT MAX(pertemuan)+1 FROM absensi WHERE siswa_id=?),1))",new Object[]{sid,date,status,sid,date,sid});}
        void addPayment(int sid,String per,long nom,String st){getWritableDatabase().execSQL("INSERT INTO pembayaran(siswa_id,periode,nominal,status) VALUES(?,?,?,?)",new Object[]{sid,per,nom,st});}
        void deletePayment(int id){getWritableDatabase().execSQL("DELETE FROM pembayaran WHERE id=?",new Object[]{id});}
        void addProgress(int sid,String mat,int nilai,String cat){getWritableDatabase().execSQL("INSERT INTO progres(siswa_id,tanggal,materi,nilai,catatan) VALUES(?,?,?,?,?)",new Object[]{sid,new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()),mat,nilai,cat});}
        void deleteProgress(int id){getWritableDatabase().execSQL("DELETE FROM progres WHERE id=?",new Object[]{id});}
    }
}
