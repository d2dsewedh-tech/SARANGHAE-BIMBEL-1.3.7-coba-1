# SARANGHAE BIMBEL v1.3.7 — HP Friendly

UI aplikasi Android diperbaiki agar lebih mendekati referensi desain SARANGHAE BIMBEL yang diberikan:
- Header ungu dengan branding dan navigasi bawah yang konsisten.
- Beranda memiliki hero/ilustrasi anak yang digambar native dengan Canvas (bukan screenshot/gambar referensi).
- Kartu ringkasan lebih lega dan responsif di layar HP.
- Menu utama menggunakan kartu dengan ikon, deskripsi, dan chevron.
- Halaman Absensi memakai pilihan status Hadir/Izin/Sakit/Alpa berbentuk tombol seperti referensi.
- Data demo siswa disesuaikan dengan contoh pada referensi.
- Database dinaikkan ke versi 4; instalasi baru mendapat 4 data demo siswa.
- Tetap menggunakan Java native + SQLite tanpa library UI eksternal.

## Build

Gunakan Gradle 8.7 + JDK 17. Workflow GitHub Actions `build-apk.yml` sudah disiapkan untuk membuat debug APK.


## v1.3.7 – Absensi 8 Pertemuan
- Setiap murid memiliki 8 slot Pertemuan.
- Tiap slot menyimpan tanggal dan status Hadir/Izin/Sakit/Alpa.
- Status yang belum diisi tetap kosong dan tidak dihitung.
- Tersedia Laporan Absensi untuk rekap Hadir, Izin, Sakit, Alpa, progres 8 pertemuan, dan tanggal terakhir.
- Database migration v4 menambahkan nomor pertemuan tanpa menghapus data absensi lama.
